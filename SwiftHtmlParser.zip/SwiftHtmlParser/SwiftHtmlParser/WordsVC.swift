//
//  WordsVC.swift
//  SwiftHtmlParser
//
//  Created by Esat Gözcü on 17.02.2018.
//  Copyright © 2018 Esat Gözcü. All rights reserved.
//

import UIKit
import SwiftSoup

class WordsVC: UIViewController,UITableViewDelegate,UITableViewDataSource{

    var contents = String()
    var allText = String()
    
    var keyArray = [String]()
    var valueArray = [Int]()
    
    var alertWord = String()
    var alertCountWord = Int()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
    
        // Metinden kelimleri ayırıyoruz.
        let setWords : [String.SubSequence] = allText.split(separator: " ")
        var allWords = Set<String>()
        // Kelimleri kümeye ekliyoruz.
        for id in setWords{
            allWords.insert(String(id))
        }
        var sonuc = Int()
        var dic =  [String: Int]()
        // Sözlüğe kelimeleri ve kaç kere kullanıldığını ekliyoruz.
        for id in allWords
        {
            let pTagsCount =  allText.components(separatedBy:id)
            sonuc = pTagsCount.count
            dic[id] = sonuc
        }
        // En çok kullanılan kelimeye göre sıralama yapıyoruz.
        let sortedDic = dic.sorted(by: { $0.value > $1.value })
        
        for item in sortedDic {
        
            // Kelimemizin en az 4 harfli olmasını sağlıyoruz.(in,at,a olmaması için)
            if item.key.count > 3
            {
                keyArray.append(item.key)
                valueArray.append(item.value)
            }
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = UITableViewCell()
        if !keyArray.isEmpty
        {
            cell.textLabel?.text = keyArray[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 10
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var wordTranslate = String()
        // Kelimleri çeviriyoruz.
        if !keyArray.isEmpty
        {
            if let url = URL(string: "http://tureng.com/tr/turkce-ingilizce/\(keyArray[indexPath.row])") {
                do {
                    contents = try String(contentsOf: url)
                } catch {
                   
                }
            } else {
                
            }
            
            do{
                let doc: Document = try SwiftSoup.parse(contents)
                
                let element = try doc.select("#englishResultsTable > tbody > tr:nth-child(4) > td.tr.ts").first()
                
                if element != nil
                {
                    wordTranslate = try (element?.text())!
                }
            }
            catch {
                
            }
            alertWord = wordTranslate
            alertCountWord = valueArray[indexPath.row]
            
            if alertWord.isEmpty
            {
                alertWord = "Kelime Bulunamadı !"
            }
            // Kelimeyi ve kaç kere kullanıldığını AlertDialog oluşturarak gösteriyoruz.
            let alert = UIAlertController(title: "Translate", message: "\n\(keyArray[indexPath.row]) : \(alertWord)\nCount : \(alertCountWord)", preferredStyle: UIAlertControllerStyle.alert)
            let okButton = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil)
            alert.addAction(okButton)
            self.present(alert, animated: true, completion: nil)
        }
    }
}

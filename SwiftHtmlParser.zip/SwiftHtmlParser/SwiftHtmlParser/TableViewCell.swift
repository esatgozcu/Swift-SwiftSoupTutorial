//
//  TableViewCell.swift
//  SwiftHtmlParser
//
//  Created by Esat Gözcü on 16.02.2018.
//  Copyright © 2018 Esat Gözcü. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var storyImage: UIImageView!
    @IBOutlet weak var storyDate: UILabel!
    @IBOutlet weak var storyTitle: UILabel!
    @IBOutlet weak var storyDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}

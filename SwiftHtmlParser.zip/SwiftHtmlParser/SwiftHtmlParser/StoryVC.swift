//
//  SecondViewController.swift
//  SwiftHtmlParser
//
//  Created by Esat Gözcü on 16.02.2018.
//  Copyright © 2018 Esat Gözcü. All rights reserved.
//

import UIKit
import SDWebImage
import SwiftSoup

class StoryVC: UIViewController {
    
    var StoryUrl = String()
    var StoryImage = String()
    var StoryDate = String()
    var StoryTitle = String()

    var contents = String()

    @IBOutlet weak var storyText: UITextView!
    @IBOutlet weak var storyTitle: UILabel!
    @IBOutlet weak var storyDate: UILabel!
    @IBOutlet weak var storyImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getHtml()
        getText()
        setView()
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue"
        {
            let destinationVC = segue.destination as! WordsVC
            
            destinationVC.allText = self.storyText.text
        }
    }
    func setView(){
        
        storyImage.sd_setImage(with: URL(string : StoryImage), completed: nil)
        storyTitle.text = StoryTitle
        storyDate.text = StoryDate
    }
    func getHtml(){
        if let url = URL(string: "https://www.wired.com\(StoryUrl)") {
            do {
                contents = try String(contentsOf: url)
            } catch {
                // contents could not be loaded
            }
        } else {
            // the URL was bad!
        }
    }
    func getText(){
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            var pTagsText = String()
            var result = Int()
            
            // Metinin bulunduğu html textleri çekiyoruz.
            let pTagsHtml : String = try! doc.select("#app-root > div > div.page-loader-component > div > div.article-main-component.article-main-component--default.article-main-component--has-photo > div > div.article-main-component__columns > main > article > div:nth-child(1)").html()
            
            if !pTagsHtml.isEmpty{
                // İçinde kaç tane </p> tagı bulunduğunu hesaplıyoruz.
                let pTagsCount =  pTagsHtml.components(separatedBy:"</p>")
                result = pTagsCount.count
            }
            if result > 1
            {
                // Her bir p tagını pTagsText ile birleştiriyoruz.
                for id in 1...result
                {
                    let storyString: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.article-main-component.article-main-component--default.article-main-component--has-photo > div > div.article-main-component__columns > main > article > div:nth-child(1) > p:nth-child(\(id))").text()
                    
                    if !storyString.isEmpty{
                        if pTagsText.isEmpty
                        {
                            pTagsText = storyString
                        }
                        else{
                            pTagsText = "\(pTagsText)\n\n\(storyString)"
                        }
                    }
                }
            }
            storyText.text = pTagsText
        }
        catch
        {
        }
    }
    
    @IBAction func wordsButton(_ sender: Any) {
        performSegue(withIdentifier: "segue", sender: nil)
    }
}

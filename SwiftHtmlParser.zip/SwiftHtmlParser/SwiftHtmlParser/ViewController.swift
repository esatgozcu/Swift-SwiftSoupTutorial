//
//  ViewController.swift
//  SwiftHtmlParser
//
//  Created by Esat Gözcü on 15.02.2018.
//  Copyright © 2018 Esat Gözcü. All rights reserved.
//

import UIKit
import SwiftSoup
import SDWebImage

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var contents = String()
    let wiredURL = "https://www.wired.com/most-recent/"
    
    var storyImageArray = [String]()
    var storyDateArray = [String]()
    var storyTitleArray = [String]()
    var storyDescriptionArray = [String]()
    var storyURLArray = [String]()
    
    var storyUrl = String()
    var storyImage = String()
    var storyDate = String()
    var storyTitle = String()

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        getHTML()
        getStoryUrl()
        getStoryImageUrl()
        getStoryDate()
        getStoryTitle()
        getStoryDescription()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return storyURLArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        
        cell.storyImage.sd_setImage(with: URL(string : self.storyImageArray[indexPath.row]))
        cell.storyDate.text = storyDateArray[indexPath.row]
        cell.storyTitle.text = storyTitleArray[indexPath.row]
        cell.storyDescription.text = storyDescriptionArray[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // TableViewden herhangi bir item seçildiğinde...
        
        storyUrl = storyURLArray[indexPath.row]
        storyImage = storyImageArray[indexPath.row]
        storyDate = storyDateArray[indexPath.row]
        storyTitle = storyTitleArray[indexPath.row]
        performSegue(withIdentifier: "segue", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Diğer sayfaya url bilgisini aktarıyoruz.
        if segue.identifier == "segue" {
            
            let destinationVC = segue.destination as! StoryVC
            destinationVC.StoryUrl = self.storyUrl
            destinationVC.StoryImage = self.storyImage
            destinationVC.StoryDate = self.storyDate
            destinationVC.StoryTitle = self.storyTitle
        }
    }
    func getHTML()
    {
        if let url = URL(string: wiredURL) {
            do {
                contents = try String(contentsOf: url)
            } catch {
            }
        } else {
        }
    }
    func getStoryImageUrl(){
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            storyImageArray.removeAll()
            for id in 1...5{
                let storyImageUrl: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > a > div > div > div > div > img").attr("src")
                storyImageArray.append(storyImageUrl)
            }
        }
        catch{

        }
    }
    func getStoryUrl(){
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            storyURLArray.removeAll()

            for id in 1...5
            {
                let storyUrl: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > a").attr("href")
                storyURLArray.append(storyUrl)
            }
        }
        catch{

        }
    }
    func getStoryDate()
    {
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            storyDateArray.removeAll()

            for id in 1...5
            {
                // Tarih
                let storyDate: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > div > div > time").text()
                // Yazar
                let storyAuthor: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > div > div > span > div > span.byline-component__content > a").text()
                // Tarih + Yazar
                let storyDateAndAuthor = storyDate+" | "+storyAuthor
                storyDateArray.append(storyDateAndAuthor)
            }
        }
        catch{
            
        }
    }
    func getStoryTitle()
    {
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            storyTitleArray.removeAll()

            for id in 1...5
            {
                let storyTitle: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > div > a > h2").text()
                storyTitleArray.append(storyTitle)
            }
        }
        catch{
            
        }
    }
    func getStoryDescription()
    {
        do{
            let doc: Document = try SwiftSoup.parse(contents)
            storyDescriptionArray.removeAll()

            for id in 1...5
            {
                let storyDescription: String = try! doc.select("#app-root > div > div.page-loader-component > div > div.main--archive-listing > div > div.archive-listing-main-component > div > div > ul > li:nth-child(\(id)) > div > a > p").text()
                storyDescriptionArray.append(storyDescription)
            }
        }
        catch{
            
        }
    }
}

